from django.contrib import admin
from .models import StudentModel
admin.site.register(StudentModel)
